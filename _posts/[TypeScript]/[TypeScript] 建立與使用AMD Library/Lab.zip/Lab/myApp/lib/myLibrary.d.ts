declare module "myLibrary/myClass" {
    export class MyClass {
        getMessage(): string;
    }
}
declare module "myLibrary" {
    export * from "myLibrary/myClass";
}
