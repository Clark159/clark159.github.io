// reference
/// <reference path="./lib/myLibrary.d.ts" />
define(["require", "exports", "myLibrary"], function (require, exports, myLibrary) {
    "use strict";
    // test
    var x = new myLibrary.MyClass();
    var message = x.getMessage();
    // alert
    alert(message);
});
//# sourceMappingURL=app.js.map