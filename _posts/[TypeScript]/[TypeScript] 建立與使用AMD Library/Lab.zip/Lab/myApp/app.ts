﻿// reference
/// <reference path="./lib/myLibrary.d.ts" />

// import
import * as myLibrary from "myLibrary";


// test
var x = new myLibrary.MyClass();
var message = x.getMessage();

// alert
alert(message);