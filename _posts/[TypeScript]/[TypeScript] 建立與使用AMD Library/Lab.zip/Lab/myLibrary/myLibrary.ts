﻿// export
export * from "./myLibrary/myClass";