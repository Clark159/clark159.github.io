﻿export class MyClass {

    // methods
    public getMessage(): string {

        return "Clark";
    }
}