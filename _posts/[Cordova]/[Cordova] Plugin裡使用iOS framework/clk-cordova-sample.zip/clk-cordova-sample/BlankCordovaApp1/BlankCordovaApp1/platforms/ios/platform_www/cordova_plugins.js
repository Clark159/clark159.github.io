cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/clk-cordova-sample/www/clk.cordova.sample.NotificationService.js",
        "id": "clk-cordova-sample.NotificationService",
        "pluginId": "clk-cordova-sample",
        "clobbers": [
            "clk.cordova.sample.NotificationService"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{}
// BOTTOM OF METADATA
});