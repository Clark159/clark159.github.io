//
//  MyFramework.h
//  MyFramework
//
//  Created by Clark on 2015/12/4.
//  Copyright © 2015年 CLK. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyFramework.
FOUNDATION_EXPORT double MyFrameworkVersionNumber;

//! Project version string for MyFramework.
FOUNDATION_EXPORT const unsigned char MyFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFramework/PublicHeader.h>
#import "MyClass.h"


