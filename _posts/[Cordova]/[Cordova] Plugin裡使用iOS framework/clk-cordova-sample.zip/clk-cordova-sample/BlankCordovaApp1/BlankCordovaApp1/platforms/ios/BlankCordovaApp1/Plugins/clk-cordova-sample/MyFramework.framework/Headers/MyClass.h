#import <Foundation/Foundation.h>

@interface MyClass : NSObject

// methods
- (NSString*) getMessage;

@end