cordova.define("clk-cordova-sample.NotificationService", function(require, exports, module) { // methods
exports.show = function (message) {
    cordova.exec(null, null, "NotificationService", "show", [message]);
};
});
