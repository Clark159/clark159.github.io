#import <MyFramework/MyFramework.h>
#import "CLKNotificationService.h"

@implementation CLKNotificationService

// methods
- (void)show:(CDVInvokedUrlCommand*)command
{
 	// test
	MyClass* x = [[MyClass alloc] init];
	NSString* message = [NSString stringWithFormat:@"%@%@", @"Hi ", [x getMessage]];         
				
	// execute
    [[[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
}

@end