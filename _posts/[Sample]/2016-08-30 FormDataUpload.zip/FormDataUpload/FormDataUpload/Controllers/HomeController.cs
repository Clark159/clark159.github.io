﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public string Test001(int data001)
        {
            return data001.ToString();
        }

        public string Test002(int data001, HttpPostedFileBase file002)
        {
            return data001.ToString();
        }
    }
}