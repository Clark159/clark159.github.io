//
//  main.m
//  MyAPP
//
//  Created by Clark on 2015/12/4.
//  Copyright © 2015年 CLK. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
