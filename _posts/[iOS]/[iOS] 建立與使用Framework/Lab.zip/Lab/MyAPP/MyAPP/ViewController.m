#import <MyFramework/MyFramework.h>
#import "ViewController.h"


@implementation ViewController

- (void)viewDidLoad {
    
    // super
    [super viewDidLoad];
    
    
    // test
    MyClass* x = [[MyClass alloc] init];
    NSString* message = [x getMessage];
    
    // alert
    [[[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];
}

@end