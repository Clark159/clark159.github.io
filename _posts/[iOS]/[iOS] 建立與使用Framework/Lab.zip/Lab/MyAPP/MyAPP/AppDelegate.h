//
//  AppDelegate.h
//  MyAPP
//
//  Created by Clark on 2015/12/4.
//  Copyright © 2015年 CLK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

