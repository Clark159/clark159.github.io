#import "MyClass.h"

@implementation MyClass

// methods
- (NSString*) getMessage {
    return @"Clark";
}

@end