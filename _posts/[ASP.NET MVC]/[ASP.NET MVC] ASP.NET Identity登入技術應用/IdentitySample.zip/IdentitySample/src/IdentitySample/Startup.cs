﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNet.Builder;
using Microsoft.AspNet.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNet.Authentication.Cookies;
using Microsoft.AspNet.Http;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace IdentitySample
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            // Set up configuration sources.
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Authentication
            services.AddAuthentication(options =>
            {
                options.SignInScheme = IdentityOptions.Current.ExternalCookieAuthenticationScheme;
            });

            // MVC
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseIISPlatformHandler();

            app.UseStaticFiles();

            // Authentication
            app.UseCookieAuthentication(options =>
            {
                options.AuthenticationScheme = IdentityOptions.Current.ApplicationCookieAuthenticationScheme;
                options.AutomaticAuthenticate = true;
                options.AutomaticChallenge = true;
                options.LoginPath = new PathString("/Account/login");
            });

            app.UseCookieAuthentication(options =>
            {
                options.AuthenticationScheme = IdentityOptions.Current.ExternalCookieAuthenticationScheme;
                options.AutomaticAuthenticate = false;
                options.AutomaticChallenge = false;
                options.LoginPath = null;
            });

            app.UseFacebookAuthentication(options =>
            {                
                options.AppId = "770764239696406";
                options.AppSecret = "2eecc0b9ef785e43bcd4779e2803ba0f";
                options.Scope.Add("email");
                options.UserInformationEndpoint = "https://graph.facebook.com/v2.5/me?fields=id,name,email";
            });

            // MVC
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        // Entry point for the application.
        public static void Main(string[] args) => WebApplication.Run<Startup>(args);
    }
}
